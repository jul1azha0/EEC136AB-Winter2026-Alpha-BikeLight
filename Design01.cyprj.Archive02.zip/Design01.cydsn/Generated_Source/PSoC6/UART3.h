/***************************************************************************//**
* \file UART3.h
* \version 2.0
*
*  This file provides constants and parameter values for the UART component.
*
********************************************************************************
* \copyright
* Copyright 2016-2017, Cypress Semiconductor Corporation. All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(UART3_CY_SCB_UART_PDL_H)
#define UART3_CY_SCB_UART_PDL_H

#include "cyfitter.h"
#include "scb/cy_scb_uart.h"

#if defined(__cplusplus)
extern "C" {
#endif

/***************************************
*   Initial Parameter Constants
****************************************/

#define UART3_DIRECTION  (3U)
#define UART3_ENABLE_RTS (0U)
#define UART3_ENABLE_CTS (0U)

/* UART direction enum */
#define UART3_RX    (0x1U)
#define UART3_TX    (0x2U)

#define UART3_ENABLE_RX  (0UL != (UART3_DIRECTION & UART3_RX))
#define UART3_ENABLE_TX  (0UL != (UART3_DIRECTION & UART3_TX))


/***************************************
*        Function Prototypes
***************************************/
/**
* \addtogroup group_general
* @{
*/
/* Component specific functions. */
void UART3_Start(void);

/* Basic functions */
__STATIC_INLINE cy_en_scb_uart_status_t UART3_Init(cy_stc_scb_uart_config_t const *config);
__STATIC_INLINE void UART3_DeInit(void);
__STATIC_INLINE void UART3_Enable(void);
__STATIC_INLINE void UART3_Disable(void);

/* Register callback. */
__STATIC_INLINE void UART3_RegisterCallback(cy_cb_scb_uart_handle_events_t callback);

/* Configuration change. */
#if (UART3_ENABLE_CTS)
__STATIC_INLINE void UART3_EnableCts(void);
__STATIC_INLINE void UART3_DisableCts(void);
#endif /* (UART3_ENABLE_CTS) */

#if (UART3_ENABLE_RTS)
__STATIC_INLINE void     UART3_SetRtsFifoLevel(uint32_t level);
__STATIC_INLINE uint32_t UART3_GetRtsFifoLevel(void);
#endif /* (UART3_ENABLE_RTS) */

__STATIC_INLINE void UART3_EnableSkipStart(void);
__STATIC_INLINE void UART3_DisableSkipStart(void);

#if (UART3_ENABLE_RX)
/* Low level: Receive direction. */
__STATIC_INLINE uint32_t UART3_Get(void);
__STATIC_INLINE uint32_t UART3_GetArray(void *buffer, uint32_t size);
__STATIC_INLINE void     UART3_GetArrayBlocking(void *buffer, uint32_t size);
__STATIC_INLINE uint32_t UART3_GetRxFifoStatus(void);
__STATIC_INLINE void     UART3_ClearRxFifoStatus(uint32_t clearMask);
__STATIC_INLINE uint32_t UART3_GetNumInRxFifo(void);
__STATIC_INLINE void     UART3_ClearRxFifo(void);
#endif /* (UART3_ENABLE_RX) */

#if (UART3_ENABLE_TX)
/* Low level: Transmit direction. */
__STATIC_INLINE uint32_t UART3_Put(uint32_t data);
__STATIC_INLINE uint32_t UART3_PutArray(void *buffer, uint32_t size);
__STATIC_INLINE void     UART3_PutArrayBlocking(void *buffer, uint32_t size);
__STATIC_INLINE void     UART3_PutString(char_t const string[]);
__STATIC_INLINE void     UART3_SendBreakBlocking(uint32_t breakWidth);
__STATIC_INLINE uint32_t UART3_GetTxFifoStatus(void);
__STATIC_INLINE void     UART3_ClearTxFifoStatus(uint32_t clearMask);
__STATIC_INLINE uint32_t UART3_GetNumInTxFifo(void);
__STATIC_INLINE bool     UART3_IsTxComplete(void);
__STATIC_INLINE void     UART3_ClearTxFifo(void);
#endif /* (UART3_ENABLE_TX) */

#if (UART3_ENABLE_RX)
/* High level: Ring buffer functions. */
__STATIC_INLINE void     UART3_StartRingBuffer(void *buffer, uint32_t size);
__STATIC_INLINE void     UART3_StopRingBuffer(void);
__STATIC_INLINE void     UART3_ClearRingBuffer(void);
__STATIC_INLINE uint32_t UART3_GetNumInRingBuffer(void);

/* High level: Receive direction functions. */
__STATIC_INLINE cy_en_scb_uart_status_t UART3_Receive(void *buffer, uint32_t size);
__STATIC_INLINE void     UART3_AbortReceive(void);
__STATIC_INLINE uint32_t UART3_GetReceiveStatus(void);
__STATIC_INLINE uint32_t UART3_GetNumReceived(void);
#endif /* (UART3_ENABLE_RX) */

#if (UART3_ENABLE_TX)
/* High level: Transmit direction functions. */
__STATIC_INLINE cy_en_scb_uart_status_t UART3_Transmit(void *buffer, uint32_t size);
__STATIC_INLINE void     UART3_AbortTransmit(void);
__STATIC_INLINE uint32_t UART3_GetTransmitStatus(void);
__STATIC_INLINE uint32_t UART3_GetNumLeftToTransmit(void);
#endif /* (UART3_ENABLE_TX) */

/* Interrupt handler */
__STATIC_INLINE void UART3_Interrupt(void);
/** @} group_general */


/***************************************
*    Variables with External Linkage
***************************************/
/**
* \addtogroup group_globals
* @{
*/
extern uint8_t UART3_initVar;
extern cy_stc_scb_uart_config_t const UART3_config;
extern cy_stc_scb_uart_context_t UART3_context;
/** @} group_globals */


/***************************************
*         Preprocessor Macros
***************************************/
/**
* \addtogroup group_macros
* @{
*/
/** The pointer to the base address of the hardware */
#define UART3_HW     ((CySCB_Type *) UART3_SCB__HW)
/** @} group_macros */


/***************************************
*    In-line Function Implementation
***************************************/

/*******************************************************************************
* Function Name: UART3_Init
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_Init() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE cy_en_scb_uart_status_t UART3_Init(cy_stc_scb_uart_config_t const *config)
{
   return Cy_SCB_UART_Init(UART3_HW, config, &UART3_context);
}


/*******************************************************************************
* Function Name: UART3_DeInit
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_DeInit() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void UART3_DeInit(void)
{
    Cy_SCB_UART_DeInit(UART3_HW);
}


/*******************************************************************************
* Function Name: UART3_Enable
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_Enable() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void UART3_Enable(void)
{
    Cy_SCB_UART_Enable(UART3_HW);
}


/*******************************************************************************
* Function Name: UART3_Disable
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_Disable() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void UART3_Disable(void)
{
    Cy_SCB_UART_Disable(UART3_HW, &UART3_context);
}


/*******************************************************************************
* Function Name: UART3_RegisterCallback
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_RegisterCallback() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void UART3_RegisterCallback(cy_cb_scb_uart_handle_events_t callback)
{
    Cy_SCB_UART_RegisterCallback(UART3_HW, callback, &UART3_context);
}


#if (UART3_ENABLE_CTS)
/*******************************************************************************
* Function Name: UART3_EnableCts
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_EnableCts() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void UART3_EnableCts(void)
{
    Cy_SCB_UART_EnableCts(UART3_HW);
}


/*******************************************************************************
* Function Name: Cy_SCB_UART_DisableCts
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_DisableCts() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void UART3_DisableCts(void)
{
    Cy_SCB_UART_DisableCts(UART3_HW);
}
#endif /* (UART3_ENABLE_CTS) */


#if (UART3_ENABLE_RTS)
/*******************************************************************************
* Function Name: UART3_SetRtsFifoLevel
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_SetRtsFifoLevel() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void UART3_SetRtsFifoLevel(uint32_t level)
{
    Cy_SCB_UART_SetRtsFifoLevel(UART3_HW, level);
}


/*******************************************************************************
* Function Name: UART3_GetRtsFifoLevel
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_GetRtsFifoLevel() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t UART3_GetRtsFifoLevel(void)
{
    return Cy_SCB_UART_GetRtsFifoLevel(UART3_HW);
}
#endif /* (UART3_ENABLE_RTS) */


/*******************************************************************************
* Function Name: UART3_EnableSkipStart
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_EnableSkipStart() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void UART3_EnableSkipStart(void)
{
    Cy_SCB_UART_EnableSkipStart(UART3_HW);
}


/*******************************************************************************
* Function Name: UART3_DisableSkipStart
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_DisableSkipStart() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void UART3_DisableSkipStart(void)
{
    Cy_SCB_UART_DisableSkipStart(UART3_HW);
}


#if (UART3_ENABLE_RX)
/*******************************************************************************
* Function Name: UART3_Get
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_Get() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t UART3_Get(void)
{
    return Cy_SCB_UART_Get(UART3_HW);
}


/*******************************************************************************
* Function Name: UART3_GetArray
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_GetArray() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t UART3_GetArray(void *buffer, uint32_t size)
{
    return Cy_SCB_UART_GetArray(UART3_HW, buffer, size);
}


/*******************************************************************************
* Function Name: UART3_GetArrayBlocking
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_GetArrayBlocking() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void UART3_GetArrayBlocking(void *buffer, uint32_t size)
{
    Cy_SCB_UART_GetArrayBlocking(UART3_HW, buffer, size);
}


/*******************************************************************************
* Function Name: UART3_GetRxFifoStatus
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_GetRxFifoStatus() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t UART3_GetRxFifoStatus(void)
{
    return Cy_SCB_UART_GetRxFifoStatus(UART3_HW);
}


/*******************************************************************************
* Function Name: UART3_ClearRxFifoStatus
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_ClearRxFifoStatus() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void UART3_ClearRxFifoStatus(uint32_t clearMask)
{
    Cy_SCB_UART_ClearRxFifoStatus(UART3_HW, clearMask);
}


/*******************************************************************************
* Function Name: UART3_GetNumInRxFifo
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_GetNumInRxFifo() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t UART3_GetNumInRxFifo(void)
{
    return Cy_SCB_UART_GetNumInRxFifo(UART3_HW);
}


/*******************************************************************************
* Function Name: UART3_ClearRxFifo
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_ClearRxFifo() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void UART3_ClearRxFifo(void)
{
    Cy_SCB_UART_ClearRxFifo(UART3_HW);
}
#endif /* (UART3_ENABLE_RX) */


#if (UART3_ENABLE_TX)
/*******************************************************************************
* Function Name: UART3_Put
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_Put() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t UART3_Put(uint32_t data)
{
    return Cy_SCB_UART_Put(UART3_HW,data);
}


/*******************************************************************************
* Function Name: UART3_PutArray
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_PutArray() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t UART3_PutArray(void *buffer, uint32_t size)
{
    return Cy_SCB_UART_PutArray(UART3_HW, buffer, size);
}


/*******************************************************************************
* Function Name: UART3_PutArrayBlocking
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_PutArrayBlocking() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void UART3_PutArrayBlocking(void *buffer, uint32_t size)
{
    Cy_SCB_UART_PutArrayBlocking(UART3_HW, buffer, size);
}


/*******************************************************************************
* Function Name: UART3_PutString
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_PutString() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void UART3_PutString(char_t const string[])
{
    Cy_SCB_UART_PutString(UART3_HW, string);
}


/*******************************************************************************
* Function Name: UART3_SendBreakBlocking
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_SendBreakBlocking() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void UART3_SendBreakBlocking(uint32_t breakWidth)
{
    Cy_SCB_UART_SendBreakBlocking(UART3_HW, breakWidth);
}


/*******************************************************************************
* Function Name: UART3_GetTxFifoStatus
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_GetTxFifoStatus() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t UART3_GetTxFifoStatus(void)
{
    return Cy_SCB_UART_GetTxFifoStatus(UART3_HW);
}


/*******************************************************************************
* Function Name: UART3_ClearTxFifoStatus
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_ClearTxFifoStatus() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void UART3_ClearTxFifoStatus(uint32_t clearMask)
{
    Cy_SCB_UART_ClearTxFifoStatus(UART3_HW, clearMask);
}


/*******************************************************************************
* Function Name: UART3_GetNumInTxFifo
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_GetNumInTxFifo() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t UART3_GetNumInTxFifo(void)
{
    return Cy_SCB_UART_GetNumInTxFifo(UART3_HW);
}


/*******************************************************************************
* Function Name: UART3_IsTxComplete
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_IsTxComplete() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE bool UART3_IsTxComplete(void)
{
    return Cy_SCB_UART_IsTxComplete(UART3_HW);
}


/*******************************************************************************
* Function Name: UART3_ClearTxFifo
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_ClearTxFifo() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void UART3_ClearTxFifo(void)
{
    Cy_SCB_UART_ClearTxFifo(UART3_HW);
}
#endif /* (UART3_ENABLE_TX) */


#if (UART3_ENABLE_RX)
/*******************************************************************************
* Function Name: UART3_StartRingBuffer
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_StartRingBuffer() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void UART3_StartRingBuffer(void *buffer, uint32_t size)
{
    Cy_SCB_UART_StartRingBuffer(UART3_HW, buffer, size, &UART3_context);
}


/*******************************************************************************
* Function Name: UART3_StopRingBuffer
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_StopRingBuffer() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void UART3_StopRingBuffer(void)
{
    Cy_SCB_UART_StopRingBuffer(UART3_HW, &UART3_context);
}


/*******************************************************************************
* Function Name: UART3_ClearRingBuffer
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_ClearRingBuffer() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void UART3_ClearRingBuffer(void)
{
    Cy_SCB_UART_ClearRingBuffer(UART3_HW, &UART3_context);
}


/*******************************************************************************
* Function Name: UART3_GetNumInRingBuffer
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_GetNumInRingBuffer() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t UART3_GetNumInRingBuffer(void)
{
    return Cy_SCB_UART_GetNumInRingBuffer(UART3_HW, &UART3_context);
}


/*******************************************************************************
* Function Name: UART3_Receive
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_Receive() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE cy_en_scb_uart_status_t UART3_Receive(void *buffer, uint32_t size)
{
    return Cy_SCB_UART_Receive(UART3_HW, buffer, size, &UART3_context);
}


/*******************************************************************************
* Function Name: UART3_GetReceiveStatus
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_GetReceiveStatus() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t UART3_GetReceiveStatus(void)
{
    return Cy_SCB_UART_GetReceiveStatus(UART3_HW, &UART3_context);
}


/*******************************************************************************
* Function Name: UART3_AbortReceive
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_AbortReceive() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void UART3_AbortReceive(void)
{
    Cy_SCB_UART_AbortReceive(UART3_HW, &UART3_context);
}


/*******************************************************************************
* Function Name: UART3_GetNumReceived
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_GetNumReceived() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t UART3_GetNumReceived(void)
{
    return Cy_SCB_UART_GetNumReceived(UART3_HW, &UART3_context);
}
#endif /* (UART3_ENABLE_RX) */


#if (UART3_ENABLE_TX)
/*******************************************************************************
* Function Name: UART3_Transmit
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_Transmit() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE cy_en_scb_uart_status_t UART3_Transmit(void *buffer, uint32_t size)
{
    return Cy_SCB_UART_Transmit(UART3_HW, buffer, size, &UART3_context);
}


/*******************************************************************************
* Function Name: UART3_GetTransmitStatus
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_GetTransmitStatus() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t UART3_GetTransmitStatus(void)
{
    return Cy_SCB_UART_GetTransmitStatus(UART3_HW, &UART3_context);
}


/*******************************************************************************
* Function Name: UART3_AbortTransmit
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_AbortTransmit() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void UART3_AbortTransmit(void)
{
    Cy_SCB_UART_AbortTransmit(UART3_HW, &UART3_context);
}


/*******************************************************************************
* Function Name: UART3_GetNumLeftToTransmit
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_GetNumLeftToTransmit() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t UART3_GetNumLeftToTransmit(void)
{
    return Cy_SCB_UART_GetNumLeftToTransmit(UART3_HW, &UART3_context);
}
#endif /* (UART3_ENABLE_TX) */


/*******************************************************************************
* Function Name: UART3_Interrupt
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_Interrupt() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void UART3_Interrupt(void)
{
    Cy_SCB_UART_Interrupt(UART3_HW, &UART3_context);
}

#if defined(__cplusplus)
}
#endif

#endif /* UART3_CY_SCB_UART_PDL_H */


/* [] END OF FILE */
