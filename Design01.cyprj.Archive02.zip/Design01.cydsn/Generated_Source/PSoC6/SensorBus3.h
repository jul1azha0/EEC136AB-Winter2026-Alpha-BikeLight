/***************************************************************************//**
* \file SensorBus3.c
* \version 2.0
*
*  This file provides constants and parameter values for the I2C component.
*
********************************************************************************
* \copyright
* Copyright 2016-2017, Cypress Semiconductor Corporation. All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(SensorBus3_CY_SCB_I2C_PDL_H)
#define SensorBus3_CY_SCB_I2C_PDL_H

#include "cyfitter.h"
#include "scb/cy_scb_i2c.h"

#if defined(__cplusplus)
extern "C" {
#endif

/***************************************
*   Initial Parameter Constants
****************************************/

#define SensorBus3_MODE               (0x2U)
#define SensorBus3_MODE_SLAVE_MASK    (0x1U)
#define SensorBus3_MODE_MASTER_MASK   (0x2U)

#define SensorBus3_ENABLE_SLAVE       (0UL != (SensorBus3_MODE & SensorBus3_MODE_SLAVE_MASK))
#define SensorBus3_ENABLE_MASTER      (0UL != (SensorBus3_MODE & SensorBus3_MODE_MASTER_MASK))
#define SensorBus3_MANUAL_SCL_CONTROL (0U)


/***************************************
*        Function Prototypes
***************************************/
/**
* \addtogroup group_general
* @{
*/
/* Component only APIs. */
void SensorBus3_Start(void);

/* Basic functions. */
__STATIC_INLINE cy_en_scb_i2c_status_t SensorBus3_Init(cy_stc_scb_i2c_config_t const *config);
__STATIC_INLINE void SensorBus3_DeInit (void);
__STATIC_INLINE void SensorBus3_Enable (void);
__STATIC_INLINE void SensorBus3_Disable(void);

/* Data rate configuration functions. */
__STATIC_INLINE uint32_t SensorBus3_SetDataRate(uint32_t dataRateHz, uint32_t scbClockHz);
__STATIC_INLINE uint32_t SensorBus3_GetDataRate(uint32_t scbClockHz);

/* Register callbacks. */
__STATIC_INLINE void SensorBus3_RegisterEventCallback(cy_cb_scb_i2c_handle_events_t callback);
#if (SensorBus3_ENABLE_SLAVE)
__STATIC_INLINE void SensorBus3_RegisterAddrCallback (cy_cb_scb_i2c_handle_addr_t callback);
#endif /* (SensorBus3_ENABLE_SLAVE) */

/* Configuration functions. */
#if (SensorBus3_ENABLE_SLAVE)
__STATIC_INLINE void     SensorBus3_SlaveSetAddress(uint8_t addr);
__STATIC_INLINE uint32_t SensorBus3_SlaveGetAddress(void);
__STATIC_INLINE void     SensorBus3_SlaveSetAddressMask(uint8_t addrMask);
__STATIC_INLINE uint32_t SensorBus3_SlaveGetAddressMask(void);
#endif /* (SensorBus3_ENABLE_SLAVE) */

#if (SensorBus3_ENABLE_MASTER)
__STATIC_INLINE void SensorBus3_MasterSetLowPhaseDutyCycle (uint32_t clockCycles);
__STATIC_INLINE void SensorBus3_MasterSetHighPhaseDutyCycle(uint32_t clockCycles);
#endif /* (SensorBus3_ENABLE_MASTER) */

/* Bus status. */
__STATIC_INLINE bool     SensorBus3_IsBusBusy(void);

/* Slave functions. */
#if (SensorBus3_ENABLE_SLAVE)
__STATIC_INLINE uint32_t SensorBus3_SlaveGetStatus(void);

__STATIC_INLINE void     SensorBus3_SlaveConfigReadBuf(uint8_t *buffer, uint32_t size);
__STATIC_INLINE void     SensorBus3_SlaveAbortRead(void);
__STATIC_INLINE uint32_t SensorBus3_SlaveGetReadTransferCount(void);
__STATIC_INLINE uint32_t SensorBus3_SlaveClearReadStatus(void);

__STATIC_INLINE void     SensorBus3_SlaveConfigWriteBuf(uint8_t *buffer, uint32_t size);
__STATIC_INLINE void     SensorBus3_SlaveAbortWrite(void);
__STATIC_INLINE uint32_t SensorBus3_SlaveGetWriteTransferCount(void);
__STATIC_INLINE uint32_t SensorBus3_SlaveClearWriteStatus(void);
#endif /* (SensorBus3_ENABLE_SLAVE) */

/* Master interrupt processing functions. */
#if (SensorBus3_ENABLE_MASTER)
__STATIC_INLINE uint32_t SensorBus3_MasterGetStatus(void);

__STATIC_INLINE cy_en_scb_i2c_status_t SensorBus3_MasterRead(cy_stc_scb_i2c_master_xfer_config_t *xferConfig);
__STATIC_INLINE void SensorBus3_MasterAbortRead(void);
__STATIC_INLINE cy_en_scb_i2c_status_t SensorBus3_MasterWrite(cy_stc_scb_i2c_master_xfer_config_t *xferConfig);
__STATIC_INLINE void SensorBus3_MasterAbortWrite(void);
__STATIC_INLINE uint32_t SensorBus3_MasterGetTransferCount(void);

/* Master manual processing functions. */
__STATIC_INLINE cy_en_scb_i2c_status_t SensorBus3_MasterSendStart(uint32_t address, cy_en_scb_i2c_direction_t bitRnW, uint32_t timeoutMs);
__STATIC_INLINE cy_en_scb_i2c_status_t SensorBus3_MasterSendReStart(uint32_t address, cy_en_scb_i2c_direction_t bitRnW, uint32_t timeoutMs);
__STATIC_INLINE cy_en_scb_i2c_status_t SensorBus3_MasterSendStop(uint32_t timeoutMs);
__STATIC_INLINE cy_en_scb_i2c_status_t SensorBus3_MasterReadByte(cy_en_scb_i2c_command_t ackNack, uint8_t *byte, uint32_t timeoutMs);
__STATIC_INLINE cy_en_scb_i2c_status_t SensorBus3_MasterWriteByte(uint8_t byte, uint32_t timeoutMs);
#endif /* (SensorBus3_ENABLE_MASTER) */

/* Interrupt handler. */
__STATIC_INLINE void SensorBus3_Interrupt(void);
/** @} group_general */


/***************************************
*    Variables with External Linkage
***************************************/
/**
* \addtogroup group_globals
* @{
*/
extern uint8_t SensorBus3_initVar;
extern cy_stc_scb_i2c_config_t const SensorBus3_config;
extern cy_stc_scb_i2c_context_t SensorBus3_context;
/** @} group_globals */


/***************************************
*         Preprocessor Macros
***************************************/
/**
* \addtogroup group_macros
* @{
*/
/** The pointer to the base address of the SCB instance */
#define SensorBus3_HW     ((CySCB_Type *) SensorBus3_SCB__HW)

/** The desired data rate in Hz */
#define SensorBus3_DATA_RATE_HZ      (100000U)

/** The frequency of the clock used by the Component in Hz */
#define SensorBus3_CLK_FREQ_HZ       (1562500U)

/** The number of Component clocks used by the master to generate the SCL
* low phase. This number is calculated by GUI based on the selected data rate.
*/
#define SensorBus3_LOW_PHASE_DUTY_CYCLE   (8U)

/** The number of Component clocks used by the master to generate the SCL
* high phase. This number is calculated by GUI based on the selected data rate.
*/
#define SensorBus3_HIGH_PHASE_DUTY_CYCLE  (8U)
/** @} group_macros */


/***************************************
*    In-line Function Implementation
***************************************/

/*******************************************************************************
* Function Name: SensorBus3_Init
****************************************************************************//**
*
* Invokes the Cy_SCB_I2C_Init() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE cy_en_scb_i2c_status_t SensorBus3_Init(cy_stc_scb_i2c_config_t const *config)
{
    return Cy_SCB_I2C_Init(SensorBus3_HW, config, &SensorBus3_context);
}


/*******************************************************************************
*  Function Name: SensorBus3_DeInit
****************************************************************************//**
*
* Invokes the Cy_SCB_I2C_DeInit() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void SensorBus3_DeInit(void)
{
    Cy_SCB_I2C_DeInit(SensorBus3_HW);
}


/*******************************************************************************
* Function Name: SensorBus3_Enable
****************************************************************************//**
*
* Invokes the Cy_SCB_I2C_Enable() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void SensorBus3_Enable(void)
{
    Cy_SCB_I2C_Enable(SensorBus3_HW);
}


/*******************************************************************************
* Function Name: SensorBus3_Disable
****************************************************************************//**
*
* Invokes the Cy_SCB_I2C_Disable() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void SensorBus3_Disable(void)
{
    Cy_SCB_I2C_Disable(SensorBus3_HW, &SensorBus3_context);
}


/*******************************************************************************
* Function Name: SensorBus3_SetDataRate
****************************************************************************//**
*
* Invokes the Cy_SCB_I2C_SetDataRate() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t SensorBus3_SetDataRate(uint32_t dataRateHz, uint32_t scbClockHz)
{
    return Cy_SCB_I2C_SetDataRate(SensorBus3_HW, dataRateHz, scbClockHz);
}


/*******************************************************************************
* Function Name: SensorBus3_GetDataRate
****************************************************************************//**
*
* Invokes the Cy_SCB_I2C_GetDataRate() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t SensorBus3_GetDataRate(uint32_t scbClockHz)
{
    return Cy_SCB_I2C_GetDataRate(SensorBus3_HW, scbClockHz);
}


/*******************************************************************************
* Function Name: SensorBus3_RegisterEventCallback
****************************************************************************//**
*
* Invokes the Cy_SCB_I2C_RegisterEventCallback() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void SensorBus3_RegisterEventCallback(cy_cb_scb_i2c_handle_events_t callback)
{
    Cy_SCB_I2C_RegisterEventCallback(SensorBus3_HW, callback, &SensorBus3_context);
}


#if (SensorBus3_ENABLE_SLAVE)
/*******************************************************************************
* Function Name: SensorBus3_RegisterAddrCallback
****************************************************************************//**
*
* Invokes the Cy_SCB_I2C_RegisterAddrCallback() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void SensorBus3_RegisterAddrCallback(cy_cb_scb_i2c_handle_addr_t callback)
{
    Cy_SCB_I2C_RegisterAddrCallback(SensorBus3_HW, callback, &SensorBus3_context);
}
#endif /* (SensorBus3_ENABLE_SLAVE) */


/*******************************************************************************
* Function Name: SensorBus3_IsBusBusy
****************************************************************************//**
*
* Invokes the Cy_SCB_I2C_IsBusBusy() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE bool SensorBus3_IsBusBusy(void)
{
    return Cy_SCB_I2C_IsBusBusy(SensorBus3_HW);
}


#if (SensorBus3_ENABLE_SLAVE)
/*******************************************************************************
* Function Name: SensorBus3_SlaveSetAddress
****************************************************************************//**
*
* Invokes the Cy_SCB_I2C_SlaveGetAddress() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void SensorBus3_SlaveSetAddress(uint8_t addr)
{
    Cy_SCB_I2C_SlaveSetAddress(SensorBus3_HW, addr);
}


/*******************************************************************************
* Function Name: SensorBus3_SlaveGetAddress
****************************************************************************//**
*
* Invokes the Cy_SCB_I2C_SlaveGetAddress() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t SensorBus3_SlaveGetAddress(void)
{
    return Cy_SCB_I2C_SlaveGetAddress(SensorBus3_HW);
}


/*******************************************************************************
* Function Name: SensorBus3_SlaveSetAddressMask
****************************************************************************//**
*
* Invokes the Cy_SCB_I2C_SlaveSetAddressMask() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void SensorBus3_SlaveSetAddressMask(uint8_t addrMask)
{
    Cy_SCB_I2C_SlaveSetAddressMask(SensorBus3_HW, addrMask);
}


/*******************************************************************************
* Function Name: SensorBus3_SlaveGetAddressMask
****************************************************************************//**
*
* Invokes the Cy_SCB_I2C_SlaveGetAddressMask() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t SensorBus3_SlaveGetAddressMask(void)
{
    return Cy_SCB_I2C_SlaveGetAddressMask(SensorBus3_HW);
}
#endif /* (SensorBus3_ENABLE_SLAVE) */

#if (SensorBus3_ENABLE_MASTER)
/*******************************************************************************
* Function Name: SensorBus3_MasterSetLowPhaseDutyCycle
****************************************************************************//**
*
* Invokes the Cy_SCB_I2C_MasterSetLowPhaseDutyCycle() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void SensorBus3_MasterSetLowPhaseDutyCycle(uint32_t clockCycles)
{
    Cy_SCB_I2C_MasterSetLowPhaseDutyCycle(SensorBus3_HW, clockCycles);
}


/*******************************************************************************
* Function Name: SensorBus3_MasterSetHighPhaseDutyCycle
****************************************************************************//**
*
* Invokes the Cy_SCB_I2C_MasterSetHighPhaseDutyCycle() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void SensorBus3_MasterSetHighPhaseDutyCycle(uint32_t clockCycles)
{
    Cy_SCB_I2C_MasterSetHighPhaseDutyCycle(SensorBus3_HW, clockCycles);
}
#endif /* (SensorBus3_ENABLE_MASTER) */


#if (SensorBus3_ENABLE_SLAVE)
/*******************************************************************************
* Function Name: SensorBus3_SlaveGetStatus
****************************************************************************//**
*
* Invokes the Cy_SCB_I2C_SlaveGetStatus() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t SensorBus3_SlaveGetStatus(void)
{
    return Cy_SCB_I2C_SlaveGetStatus(SensorBus3_HW, &SensorBus3_context);
}


/*******************************************************************************
* Function Name: SensorBus3_SlaveConfigReadBuf
****************************************************************************//**
*
* Invokes the Cy_SCB_I2C_SlaveConfigReadBuf() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void SensorBus3_SlaveConfigReadBuf(uint8_t *buffer, uint32_t size)
{
    Cy_SCB_I2C_SlaveConfigReadBuf(SensorBus3_HW, buffer, size, &SensorBus3_context);
}


/*******************************************************************************
* Function Name: SensorBus3_SlaveAbortRead
****************************************************************************//**
*
* Invokes the Cy_SCB_I2C_SlaveAbortRead() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void SensorBus3_SlaveAbortRead(void)
{
    Cy_SCB_I2C_SlaveAbortRead(SensorBus3_HW, &SensorBus3_context);
}


/*******************************************************************************
* Function Name: SensorBus3_SlaveGetReadTransferCount
****************************************************************************//**
*
* Invokes the Cy_SCB_I2C_SlaveGetReadTransferCount() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t SensorBus3_SlaveGetReadTransferCount(void)
{
    return Cy_SCB_I2C_SlaveGetReadTransferCount(SensorBus3_HW, &SensorBus3_context);
}


/*******************************************************************************
* Function Name: SensorBus3_SlaveClearReadStatus
****************************************************************************//**
*
* Invokes the Cy_SCB_I2C_SlaveClearReadStatus() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t SensorBus3_SlaveClearReadStatus(void)
{
    return Cy_SCB_I2C_SlaveClearReadStatus(SensorBus3_HW, &SensorBus3_context);
}


/*******************************************************************************
* Function Name: SensorBus3_SlaveConfigWriteBuf
****************************************************************************//**
*
* Invokes the Cy_SCB_I2C_SlaveConfigWriteBuf() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void SensorBus3_SlaveConfigWriteBuf(uint8_t *buffer, uint32_t size)
{
    Cy_SCB_I2C_SlaveConfigWriteBuf(SensorBus3_HW, buffer, size, &SensorBus3_context);
}


/*******************************************************************************
* Function Name: SensorBus3_SlaveAbortWrite
****************************************************************************//**
*
* Invokes the Cy_SCB_I2C_SlaveAbortWrite() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void SensorBus3_SlaveAbortWrite(void)
{
    Cy_SCB_I2C_SlaveAbortWrite(SensorBus3_HW, &SensorBus3_context);
}


/*******************************************************************************
* Function Name: SensorBus3_SlaveGetWriteTransferCount
****************************************************************************//**
*
* Invokes the Cy_SCB_I2C_SlaveGetWriteTransferCount() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t SensorBus3_SlaveGetWriteTransferCount(void)
{
    return Cy_SCB_I2C_SlaveGetWriteTransferCount(SensorBus3_HW, &SensorBus3_context);
}


/*******************************************************************************
* Function Name: SensorBus3_SlaveClearWriteStatus
****************************************************************************//**
*
* Invokes the Cy_SCB_I2C_SlaveClearWriteStatus() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t SensorBus3_SlaveClearWriteStatus(void)
{
    return Cy_SCB_I2C_SlaveClearWriteStatus(SensorBus3_HW, &SensorBus3_context);
}
#endif /* (SensorBus3_ENABLE_SLAVE) */


#if (SensorBus3_ENABLE_MASTER)
/*******************************************************************************
* Function Name: SensorBus3_MasterGetStatus
****************************************************************************//**
*
* Invokes the Cy_SCB_I2C_MasterGetStatus() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t SensorBus3_MasterGetStatus(void)
{
    return Cy_SCB_I2C_MasterGetStatus(SensorBus3_HW, &SensorBus3_context);
}


/*******************************************************************************
* Function Name: SensorBus3_MasterRead
****************************************************************************//**
*
* Invokes the Cy_SCB_I2C_MasterRead() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE cy_en_scb_i2c_status_t SensorBus3_MasterRead(cy_stc_scb_i2c_master_xfer_config_t *xferConfig)
{
    return Cy_SCB_I2C_MasterRead(SensorBus3_HW, xferConfig, &SensorBus3_context);
}


/*******************************************************************************
* Function Name: SensorBus3_MasterAbortRead
****************************************************************************//**
*
* Invokes the Cy_SCB_I2C_MasterAbortRead() PDL driver function.
*
******************************************************************************/
__STATIC_INLINE void SensorBus3_MasterAbortRead(void)
{
    Cy_SCB_I2C_MasterAbortRead(SensorBus3_HW, &SensorBus3_context);
}


/*******************************************************************************
* Function Name: SensorBus3_MasterWrite
****************************************************************************//**
*
* Invokes the Cy_SCB_I2C_MasterWrite() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE cy_en_scb_i2c_status_t SensorBus3_MasterWrite(cy_stc_scb_i2c_master_xfer_config_t *xferConfig)
{
    return Cy_SCB_I2C_MasterWrite(SensorBus3_HW, xferConfig, &SensorBus3_context);
}


/*******************************************************************************
* Function Name: SensorBus3_MasterAbortWrite
****************************************************************************//**
*
* Invokes the Cy_SCB_I2C_MasterAbortWrite() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void SensorBus3_MasterAbortWrite(void)
{
    Cy_SCB_I2C_MasterAbortWrite(SensorBus3_HW, &SensorBus3_context);
}


/*******************************************************************************
* Function Name: SensorBus3_MasterGetTransferCount
****************************************************************************//**
*
* Invokes the Cy_SCB_I2C_MasterGetTransferCount() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t SensorBus3_MasterGetTransferCount(void)
{
    return Cy_SCB_I2C_MasterGetTransferCount(SensorBus3_HW, &SensorBus3_context);
}


/*******************************************************************************
* Function Name: SensorBus3_MasterSendStart
****************************************************************************//**
*
* Invokes the Cy_SCB_I2C_MasterSendStart() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE cy_en_scb_i2c_status_t SensorBus3_MasterSendStart(uint32_t address, cy_en_scb_i2c_direction_t bitRnW, uint32_t timeoutMs)
{
    return Cy_SCB_I2C_MasterSendStart(SensorBus3_HW, address, bitRnW, timeoutMs, &SensorBus3_context);
}


/*******************************************************************************
* Function Name: SensorBus3_MasterSendReStart
****************************************************************************//**
*
* Invokes the Cy_SCB_I2C_MasterSendReStart() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE cy_en_scb_i2c_status_t SensorBus3_MasterSendReStart(uint32_t address, cy_en_scb_i2c_direction_t bitRnW, uint32_t timeoutMs)
{
    return Cy_SCB_I2C_MasterSendReStart(SensorBus3_HW, address, bitRnW, timeoutMs, &SensorBus3_context);
}


/*******************************************************************************
* Function Name: SensorBus3_MasterSendStop
****************************************************************************//**
*
* Invokes the Cy_SCB_I2C_MasterSendStop() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE cy_en_scb_i2c_status_t SensorBus3_MasterSendStop(uint32_t timeoutMs)
{
    return Cy_SCB_I2C_MasterSendStop(SensorBus3_HW, timeoutMs, &SensorBus3_context);
}


/*******************************************************************************
* Function Name: SensorBus3_MasterReadByte
****************************************************************************//**
*
* Invokes the Cy_SCB_I2C_MasterReadByte() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE cy_en_scb_i2c_status_t SensorBus3_MasterReadByte(cy_en_scb_i2c_command_t ackNack, uint8_t *byte, uint32_t timeoutMs)
{
    return Cy_SCB_I2C_MasterReadByte(SensorBus3_HW, ackNack, byte, timeoutMs, &SensorBus3_context);
}


/*******************************************************************************
* Function Name: SensorBus3_MasterWriteByte
****************************************************************************//**
*
* Invokes the Cy_SCB_I2C_MasterWriteByte() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE cy_en_scb_i2c_status_t SensorBus3_MasterWriteByte(uint8_t byte, uint32_t timeoutMs)
{
    return Cy_SCB_I2C_MasterWriteByte(SensorBus3_HW, byte, timeoutMs, &SensorBus3_context);
}
#endif /* (SensorBus3_ENABLE_MASTER) */


/*******************************************************************************
* Function Name: SensorBus3_Interrupt
****************************************************************************//**
*
* Invokes the Cy_SCB_I2C_Interrupt() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void SensorBus3_Interrupt(void)
{
    Cy_SCB_I2C_Interrupt(SensorBus3_HW, &SensorBus3_context);
}

#if defined(__cplusplus)
}
#endif

#endif /* SensorBus3_CY_SCB_I2C_PDL_H */


/* [] END OF FILE */
